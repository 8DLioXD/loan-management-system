import { useMemo } from 'react';
import { Loan, Payment } from '../types/loan';

export const useLoanCalculations = (loan: Loan) => {
  return useMemo(() => {
    const calculateTotal = () => {
      const principal = Number(loan.amount);
      const interest = Math.round(principal * (Number(loan.interestRate) / 100));
      return principal + interest;
    };

    const calculateTotalPaid = () => {
      return loan.payments.reduce((sum, payment) => sum + payment.amount, 0);
    };

    const calculateRemaining = () => {
      const total = calculateTotal();
      const paid = calculateTotalPaid();
      return Math.max(0, total - paid);
    };

    const isOverdue = () => {
      return !loan.paid && new Date(loan.dueDate) < new Date();
    };

    return {
      total: calculateTotal(),
      totalPaid: calculateTotalPaid(),
      remaining: calculateRemaining(),
      isOverdue: isOverdue()
    };
  }, [loan]);
};