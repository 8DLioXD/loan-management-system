import { useState, useEffect } from 'react';
import { verifyToken, generateToken } from '../utils/security';
import { SECURITY } from '../utils/constants';

export const useSession = () => {
  const [isValid, setIsValid] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const checkSession = async () => {
      try {
        const token = localStorage.getItem('authToken');
        if (!token) {
          setIsValid(false);
          return;
        }

        await verifyToken(token);
        setIsValid(true);
      } catch (error) {
        console.error('Session validation error:', error);
        setIsValid(false);
        localStorage.removeItem('authToken');
        localStorage.removeItem('auth');
      } finally {
        setIsChecking(false);
      }
    };

    checkSession();
  }, []);

  useEffect(() => {
    if (!isValid) return;

    const refreshToken = async () => {
      try {
        const currentToken = localStorage.getItem('authToken');
        if (!currentToken) return;

        const payload = await verifyToken(currentToken);
        const newToken = await generateToken(payload.userId);
        localStorage.setItem('authToken', newToken);
      } catch (error) {
        console.error('Token refresh error:', error);
        setIsValid(false);
        localStorage.removeItem('authToken');
        localStorage.removeItem('auth');
      }
    };

    const interval = setInterval(refreshToken, SECURITY.SESSION_REFRESH_INTERVAL);
    return () => clearInterval(interval);
  }, [isValid]);

  return { isValid, isChecking };
};