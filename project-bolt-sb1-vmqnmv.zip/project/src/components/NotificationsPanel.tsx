import React, { useEffect, useRef } from 'react';
import { X, Bell, AlertCircle, CheckCircle, Clock, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface NotificationsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const NotificationsPanel: React.FC<NotificationsPanelProps> = ({ isOpen, onClose }) => {
  const [showAll, setShowAll] = React.useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const [notifications] = React.useState([
    {
      id: 1,
      type: 'warning',
      message: 'El préstamo de Juan Pérez vence en 3 días',
      time: '2 horas',
      read: false
    },
    {
      id: 2,
      type: 'success',
      message: 'Pago registrado exitosamente para María González',
      time: '5 horas',
      read: true
    },
    {
      id: 3,
      type: 'info',
      message: 'Nuevo cliente Carlos Rodríguez registrado',
      time: '1 día',
      read: true
    }
  ]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEsc);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-yellow-400" />;
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'info':
        return <Bell className="w-5 h-5 text-blue-400" />;
      default:
        return <Bell className="w-5 h-5 text-slate-400" />;
    }
  };

  const displayedNotifications = showAll ? notifications : notifications.slice(0, 3);
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={panelRef}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="absolute right-4 top-16 w-96 bg-slate-800 rounded-lg shadow-xl border border-slate-700 z-50"
        >
          <div className="p-4 border-b border-slate-700 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold text-white">
                Notificaciones
              </h3>
              {unreadCount > 0 && (
                <span className="px-2 py-1 text-xs font-medium bg-blue-500/20 text-blue-400 rounded-full">
                  {unreadCount} nueva{unreadCount !== 1 ? 's' : ''}
                </span>
              )}
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="max-h-[400px] overflow-y-auto">
            <AnimatePresence>
              {displayedNotifications.map((notification, index) => (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 border-b border-slate-700 hover:bg-slate-700/50 transition-colors cursor-pointer ${
                    !notification.read ? 'bg-blue-500/10' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {getIcon(notification.type)}
                    <div className="flex-1">
                      <p className="text-sm text-white">
                        {notification.message}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Clock className="w-4 h-4 text-slate-400" />
                        <span className="text-xs text-slate-400">
                          Hace {notification.time}
                        </span>
                      </div>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 rounded-full bg-blue-400" />
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <div className="p-4 border-t border-slate-700">
            <button 
              onClick={() => setShowAll(!showAll)}
              className="w-full text-center text-sm text-blue-400 hover:text-blue-300 flex items-center justify-center gap-2"
            >
              {showAll ? 'Mostrar menos' : 'Ver todas las notificaciones'}
              <ChevronRight className={`w-4 h-4 transform transition-transform ${showAll ? 'rotate-90' : ''}`} />
            </button>
          </div>

          <div className="text-xs text-center text-slate-400 p-2 border-t border-slate-700">
            Presiona ESC para cerrar
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default NotificationsPanel;