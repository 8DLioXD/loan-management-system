import React, { useState, useEffect } from 'react';
import { User } from '../types/auth';
import { useLoan } from '../context/LoanContext';
import { useTheme } from '../context/ThemeContext';
import { Search, Bell, Sun, Moon, User as UserIcon, ChevronDown } from 'lucide-react';
import FilterBar from './dashboard/FilterBar';
import StatsGrid from './dashboard/StatsGrid';
import LoanTable from './dashboard/LoanTable';
import LoanModal from './modals/LoanModal';
import PaymentModal from './modals/PaymentModal';
import SearchModal from './modals/SearchModal';
import NotificationsPanel from './NotificationsPanel';
import CreateAdminModal from './modals/CreateAdminModal';
import Toast from './Toast';
import { motion, AnimatePresence } from 'framer-motion';

interface LoanDashboardProps {
  user: User;
  onLogout: () => void;
}

const LoanDashboard: React.FC<LoanDashboardProps> = ({ user, onLogout }) => {
  const { isDarkMode, toggleTheme } = useTheme();
  const [currentFilter, setCurrentFilter] = useState('todos');
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isCreateAdminOpen, setIsCreateAdminOpen] = useState(false);
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const [isLoanModalOpen, setIsLoanModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState<any>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const { loans, addLoan, updateLoan, addPayment, deleteLoan } = useLoan();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleNewLoan = () => {
    if (user.role === 'client') {
      setToast({ message: 'No tienes permisos para crear préstamos', type: 'error' });
      return;
    }
    setSelectedLoan(null);
    setIsLoanModalOpen(true);
  };

  const handleLoanSubmit = (formData: any) => {
    if (user.role === 'client') {
      setToast({ message: 'No tienes permisos para modificar préstamos', type: 'error' });
      return;
    }

    try {
      if (selectedLoan) {
        updateLoan(selectedLoan.id, formData);
        setToast({ message: 'Préstamo actualizado exitosamente', type: 'success' });
      } else {
        addLoan(formData);
        setToast({ message: 'Préstamo creado exitosamente', type: 'success' });
      }
      setIsLoanModalOpen(false);
    } catch (error) {
      setToast({ 
        message: error instanceof Error ? error.message : 'Error al procesar el préstamo', 
        type: 'error' 
      });
    }
  };

  const handlePaymentSubmit = (paymentData: any) => {
    if (user.role === 'client') {
      setToast({ message: 'No tienes permisos para registrar pagos', type: 'error' });
      return;
    }

    try {
      if (selectedLoan) {
        addPayment(selectedLoan.id, paymentData);
        setToast({ message: 'Pago registrado exitosamente', type: 'success' });
      }
      setIsPaymentModalOpen(false);
    } catch (error) {
      setToast({ 
        message: error instanceof Error ? error.message : 'Error al registrar el pago', 
        type: 'error' 
      });
    }
  };

  const handleDeleteLoan = (loanId: string) => {
    if (user.role === 'client') {
      setToast({ message: 'No tienes permisos para eliminar préstamos', type: 'error' });
      return;
    }

    if (window.confirm('¿Está seguro de eliminar este préstamo?')) {
      try {
        deleteLoan(loanId);
        setToast({ message: 'Préstamo eliminado exitosamente', type: 'success' });
      } catch (error) {
        setToast({ 
          message: error instanceof Error ? error.message : 'Error al eliminar el préstamo', 
          type: 'error' 
        });
      }
    }
  };

  // Filter loans for client users to only show their loans
  const filteredLoans = user.role === 'client' 
    ? loans.filter(loan => loan.clientId === user.clientId)
    : loans;

  return (
    <div className="min-h-screen bg-slate-850">
      <header className="bg-slate-850 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <span className="text-xl font-semibold text-white">Sistema de Préstamos</span>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center bg-slate-800/50 rounded-lg px-4 py-2">
                <span className="text-sm text-slate-300">
                  {currentDateTime.toLocaleDateString('es-CR', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    timeZone: 'America/Costa_Rica'
                  })}
                </span>
                <span className="mx-2 text-slate-500">|</span>
                <span className="text-sm text-slate-300">
                  {currentDateTime.toLocaleTimeString('es-CR', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true,
                    timeZone: 'America/Costa_Rica'
                  })}
                </span>
              </div>

              {user.role === 'admin' && (
                <button
                  onClick={() => setIsSearchOpen(true)}
                  className="p-2 text-slate-400 hover:text-white transition-colors"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}

              <button
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className="p-2 text-slate-400 hover:text-white transition-colors"
              >
                <Bell className="w-5 h-5" />
              </button>

              <button 
                onClick={toggleTheme}
                className="p-2 text-slate-400 hover:text-white transition-colors"
              >
                {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-2 text-white hover:bg-slate-700 rounded-lg"
                >
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <UserIcon className="w-5 h-5 text-white" />
                  </div>
                  <span>{user.name}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${
                    isUserMenuOpen ? 'rotate-180' : ''
                  }`} />
                </button>

                <AnimatePresence>
                  {isUserMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute right-0 mt-2 w-48 bg-slate-800 rounded-lg shadow-lg py-1 border border-slate-700"
                    >
                      {user.role === 'admin' && (
                        <button
                          onClick={() => {
                            setIsCreateAdminOpen(true);
                            setIsUserMenuOpen(false);
                          }}
                          className="w-full px-4 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 flex items-center gap-2"
                        >
                          <UserIcon className="w-4 h-4" />
                          Crear Administrador
                        </button>
                      )}
                      <button
                        onClick={onLogout}
                        className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-slate-700 flex items-center gap-2"
                      >
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                        </svg>
                        Cerrar Sesión
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <FilterBar 
          currentFilter={currentFilter}
          onFilterChange={setCurrentFilter}
          onNewLoan={handleNewLoan}
          isClient={user.role === 'client'}
        />
        {user.role === 'admin' && <StatsGrid />}
        <LoanTable 
          filter={currentFilter}
          onEdit={(loan) => {
            setSelectedLoan(loan);
            setIsLoanModalOpen(true);
          }}
          onPayment={(loan) => {
            setSelectedLoan(loan);
            setIsPaymentModalOpen(true);
          }}
          onDelete={handleDeleteLoan}
          loans={filteredLoans}
          isClient={user.role === 'client'}
        />
      </main>

      {user.role === 'admin' && (
        <>
          <SearchModal
            isOpen={isSearchOpen}
            onClose={() => setIsSearchOpen(false)}
          />

          <NotificationsPanel
            isOpen={isNotificationsOpen}
            onClose={() => setIsNotificationsOpen(false)}
          />

          <LoanModal
            isOpen={isLoanModalOpen}
            onClose={() => setIsLoanModalOpen(false)}
            onSubmit={handleLoanSubmit}
            editingLoan={selectedLoan}
          />

          <PaymentModal
            isOpen={isPaymentModalOpen}
            onClose={() => setIsPaymentModalOpen(false)}
            onSubmit={handlePaymentSubmit}
            loan={selectedLoan}
          />

          <CreateAdminModal
            isOpen={isCreateAdminOpen}
            onClose={() => setIsCreateAdminOpen(false)}
          />
        </>
      )}

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
};

export default LoanDashboard;