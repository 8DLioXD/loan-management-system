import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Percent, DollarSign } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface LoanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (formData: any) => void;
  editingLoan?: any;
}

const LoanModal: React.FC<LoanModalProps> = ({ isOpen, onClose, onSubmit, editingLoan }) => {
  const [formData, setFormData] = useState({
    clientName: '',
    amount: '',
    interestRate: '20',
    loanDate: '',
    dueDate: ''
  });

  const [preview, setPreview] = useState({
    amount: 0,
    interest: 0,
    total: 0
  });

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
    }

    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  useEffect(() => {
    if (editingLoan) {
      setFormData({
        clientName: editingLoan.clientName,
        amount: editingLoan.amount.toString(),
        interestRate: editingLoan.interestRate.toString(),
        loanDate: editingLoan.loanDate.split('T')[0],
        dueDate: editingLoan.dueDate.split('T')[0]
      });
    } else {
      setFormData({
        clientName: '',
        amount: '',
        interestRate: '20',
        loanDate: new Date().toISOString().split('T')[0],
        dueDate: ''
      });
    }
  }, [editingLoan, isOpen]);

  useEffect(() => {
    const amount = parseFloat(formData.amount) || 0;
    const rate = parseFloat(formData.interestRate) || 0;
    const interest = Math.round(amount * (rate / 100));
    setPreview({
      amount,
      interest,
      total: amount + interest
    });
  }, [formData.amount, formData.interestRate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(formData.amount);
    const rate = parseFloat(formData.interestRate);
    
    if (isNaN(amount) || amount <= 0) {
      alert('Por favor ingrese un monto válido');
      return;
    }
    
    if (isNaN(rate) || rate < 0 || rate > 100) {
      alert('La tasa de interés debe estar entre 0% y 100%');
      return;
    }
    
    if (!formData.loanDate || !formData.dueDate) {
      alert('Por favor seleccione las fechas del préstamo');
      return;
    }

    const loanDate = new Date(formData.loanDate);
    const dueDate = new Date(formData.dueDate);
    
    if (dueDate <= loanDate) {
      alert('La fecha de vencimiento debe ser posterior a la fecha del préstamo');
      return;
    }

    onSubmit({
      clientName: formData.clientName,
      amount: amount,
      interestRate: rate,
      loanDate: formData.loanDate,
      dueDate: formData.dueDate
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-slate-800 rounded-lg shadow-xl w-full max-w-md"
          >
            <div className="p-6 border-b border-slate-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-white">
                  {editingLoan ? 'Editar Préstamo' : 'Nuevo Préstamo'}
                </h2>
                <button
                  onClick={onClose}
                  className="text-slate-400 hover:text-slate-300"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Cliente
                  </label>
                  <input
                    type="text"
                    value={formData.clientName}
                    onChange={(e) => setFormData(prev => ({ ...prev, clientName: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                             text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                    placeholder="Nombre del cliente"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Monto del Préstamo
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                      <span className="text-slate-400">₡</span>
                    </div>
                    <input
                      type="number"
                      value={formData.amount}
                      onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                      className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                               text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                      placeholder="0"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Tasa de Interés (%)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                      <Percent className="w-5 h-5 text-slate-400" />
                    </div>
                    <input
                      type="number"
                      value={formData.interestRate}
                      onChange={(e) => setFormData(prev => ({ ...prev, interestRate: e.target.value }))}
                      className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                               text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                      placeholder="20"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Fecha Préstamo
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Calendar className="w-5 h-5 text-slate-400" />
                      </div>
                      <input
                        type="date"
                        value={formData.loanDate}
                        onChange={(e) => setFormData(prev => ({ ...prev, loanDate: e.target.value }))}
                        className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                                 text-white focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Fecha Vencimiento
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <Calendar className="w-5 h-5 text-slate-400" />
                      </div>
                      <input
                        type="date"
                        value={formData.dueDate}
                        onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
                        className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                                 text-white focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-700/50 rounded-lg p-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-700 p-4 rounded-lg">
                    <h4 className="text-sm font-medium text-slate-400 mb-2">
                      Monto Principal
                    </h4>
                    <div className="text-xl font-bold text-white">
                      {formatCurrency(preview.amount)}
                    </div>
                  </div>
                  <div className="bg-slate-700 p-4 rounded-lg">
                    <h4 className="text-sm font-medium text-slate-400 mb-2">
                      Interés ({formData.interestRate}%)
                    </h4>
                    <div className="text-xl font-bold text-blue-400">
                      {formatCurrency(preview.interest)}
                    </div>
                  </div>
                </div>
                
                <div className="p-4 bg-blue-500/10 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-slate-300">
                      Total a Pagar:
                    </span>
                    <span className="text-2xl font-bold text-blue-400">
                      {formatCurrency(preview.total)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-slate-300 bg-slate-700 rounded-lg hover:bg-slate-600"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-500"
                >
                  {editingLoan ? 'Actualizar' : 'Crear'}
                </button>
              </div>

              <div className="text-xs text-center text-slate-400">
                Presiona ESC para cerrar
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoanModal;