import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatCurrency } from '../../utils/formatters';
import { calculateLoanStats } from '../../utils/calculations';
import { Calendar, X } from 'lucide-react';
import { Loan } from '../../types/loan';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (paymentData: any) => void;
  loan?: Loan;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSubmit, loan }) => {
  const [formData, setFormData] = useState({
    amount: '',
    date: ''
  });

  useEffect(() => {
    if (loan) {
      const { total, totalPaid } = calculateLoanStats(loan);
      const remainingAmount = Math.max(0, total - totalPaid);
      
      setFormData({
        amount: remainingAmount.toString(),
        date: new Date().toISOString().split('T')[0]
      });
    }
  }, [loan, isOpen]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
    }

    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      alert('Por favor ingrese un monto válido');
      return;
    }
    
    const paymentDate = new Date(formData.date);
    const today = new Date();
    const loanDate = loan ? new Date(loan.loanDate) : new Date();
    
    if (paymentDate > today) {
      alert('No se pueden registrar pagos con fecha futura');
      return;
    }
    
    if (paymentDate < loanDate) {
      alert('La fecha del pago no puede ser anterior a la fecha del préstamo');
      return;
    }
    
    onSubmit({
      amount: amount,
      date: formData.date
    });
  };

  if (!isOpen || !loan) return null;

  const { total, totalPaid, remaining } = calculateLoanStats(loan);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-slate-800 rounded-lg shadow-xl max-w-lg w-full"
          >
            <div className="p-6 border-b border-slate-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-white">
                  Registrar Pago
                </h2>
                <button
                  onClick={onClose}
                  className="text-slate-400 hover:text-slate-300"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Monto del Pago
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                      <span className="text-slate-400">₡</span>
                    </div>
                    <input
                      type="number"
                      value={formData.amount}
                      onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                      className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                               text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500"
                      required
                      min={1}
                      max={remaining}
                      step={1}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Fecha del Pago
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                      <Calendar className="w-5 h-5 text-slate-400" />
                    </div>
                    <input
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                      className="w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg 
                               text-white focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="bg-slate-700/50 rounded-lg p-4 space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <span className="text-slate-400">Monto Original:</span>
                  <span className="text-right font-mono text-white">
                    {formatCurrency(loan.amount)}
                  </span>

                  <span className="text-slate-400">Interés ({loan.interestRate}%):</span>
                  <span className="text-right font-mono text-white">
                    {formatCurrency(total - loan.amount)}
                  </span>

                  <span className="text-slate-400">Total a Pagar:</span>
                  <span className="text-right font-mono text-white">
                    {formatCurrency(total)}
                  </span>

                  <span className="text-slate-400">Total Pagado:</span>
                  <span className="text-right font-mono text-white">
                    {formatCurrency(totalPaid)}
                  </span>

                  <span className="font-medium text-white">Saldo Pendiente:</span>
                  <span className="text-right font-mono font-medium text-white">
                    {formatCurrency(remaining)}
                  </span>
                </div>
              </div>

              {loan.payments.length > 0 && (
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h3 className="text-sm font-medium text-white mb-3">
                    Historial de Pagos
                  </h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {[...loan.payments]
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((payment) => (
                        <div key={payment.id} className="flex justify-between text-sm">
                          <span className="text-slate-400">
                            {new Date(payment.date).toLocaleDateString('es-CR')}
                          </span>
                          <span className="font-mono text-white">
                            {formatCurrency(payment.amount)}
                          </span>
                        </div>
                      ))
                    }
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-slate-300 bg-slate-700 rounded-lg hover:bg-slate-600"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-white bg-green-600 rounded-lg hover:bg-green-500"
                >
                  Registrar Pago
                </button>
              </div>

              <div className="text-xs text-center text-slate-400">
                Presiona ESC para cerrar
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PaymentModal;