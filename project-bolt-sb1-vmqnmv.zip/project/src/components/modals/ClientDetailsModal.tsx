import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Calendar, DollarSign, Clock, FileText } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import { calculateLoanStats } from '../../utils/calculations';
import { Loan, Payment } from '../../types/loan';
import DOMPurify from 'dompurify';

interface ClientDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  loan: Loan | null;
}

const ClientDetailsModal: React.FC<ClientDetailsModalProps> = ({ isOpen, onClose, loan }) => {
  const stats = useMemo(() => {
    if (!loan) return null;
    return calculateLoanStats(loan);
  }, [loan]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
      return () => window.removeEventListener('keydown', handleEsc);
    }
  }, [isOpen, onClose]);

  if (!loan || !stats) return null;

  const { total, totalPaid, remaining, isOverdue, daysOverdue } = stats;

  // Sanitize client name for XSS protection
  const sanitizedClientName = DOMPurify.sanitize(loan.clientName);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => {
            if (e.target === e.currentTarget) onClose();
          }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-slate-800 rounded-lg shadow-xl max-w-2xl w-full"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-white">
                  Detalles del Cliente
                </h2>
                <button
                  onClick={onClose}
                  className="text-slate-400 hover:text-slate-300 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Información del Cliente */}
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-white mb-4 flex items-center gap-2">
                    <User className="w-5 h-5" />
                    Información del Cliente
                  </h3>
                  <div className="space-y-3">
                    <div>
                      <span className="text-slate-400">Nombre:</span>
                      <p className="text-white font-medium">{sanitizedClientName}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">ID del Préstamo:</span>
                      <p className="text-white font-mono text-sm">{loan.id}</p>
                    </div>
                  </div>
                </div>

                {/* Detalles del Préstamo */}
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-white mb-4 flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Detalles del Préstamo
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Monto Original:</span>
                      <span className="text-white font-medium">
                        {formatCurrency(loan.amount)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Interés ({loan.interestRate}%):</span>
                      <span className="text-white font-medium">
                        {formatCurrency(total - loan.amount)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total a Pagar:</span>
                      <span className="text-white font-medium">
                        {formatCurrency(total)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Estado del Préstamo */}
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-white mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Estado del Préstamo
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Fecha Inicio:</span>
                      <span className="text-white">
                        {new Date(loan.loanDate).toLocaleDateString('es-CR')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Fecha Vencimiento:</span>
                      <span className="text-white">
                        {new Date(loan.dueDate).toLocaleDateString('es-CR')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Estado:</span>
                      <span className={`px-2 py-1 rounded-full text-sm ${
                        loan.paid
                          ? 'bg-green-500/20 text-green-400'
                          : isOverdue
                          ? 'bg-red-500/20 text-red-400'
                          : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {loan.paid ? 'PAGADO' : isOverdue ? 'ATRASADO' : 'ACTIVO'}
                      </span>
                    </div>
                    {isOverdue && !loan.paid && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Días de Atraso:</span>
                        <span className="text-red-400 font-medium">{daysOverdue} días</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Resumen de Pagos */}
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-white mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Resumen de Pagos
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total Pagado:</span>
                      <span className="text-white font-medium">
                        {formatCurrency(totalPaid)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Saldo Pendiente:</span>
                      <span className="text-white font-medium">
                        {formatCurrency(remaining)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Pagos Realizados:</span>
                      <span className="text-white font-medium">
                        {loan.payments.length}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Historial de Pagos */}
              {loan.payments.length > 0 && (
                <div className="mt-6">
                  <h3 className="text-lg font-medium text-white mb-4">
                    Historial de Pagos
                  </h3>
                  <div className="bg-slate-700/50 rounded-lg overflow-hidden">
                    <table className="w-full">
                      <thead className="bg-slate-700">
                        <tr>
                          <th className="px-4 py-2 text-left text-sm font-medium text-slate-300">
                            Fecha
                          </th>
                          <th className="px-4 py-2 text-right text-sm font-medium text-slate-300">
                            Monto
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700">
                        {[...loan.payments]
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .map((payment: Payment) => (
                            <tr key={payment.id} className="hover:bg-slate-700/50">
                              <td className="px-4 py-2 text-sm text-slate-300">
                                {new Date(payment.date).toLocaleDateString('es-CR')}
                              </td>
                              <td className="px-4 py-2 text-sm text-right font-medium text-white">
                                {formatCurrency(payment.amount)}
                              </td>
                            </tr>
                          ))
                        }
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-700">
              <div className="flex justify-end">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-slate-300 bg-slate-700 rounded-lg hover:bg-slate-600 transition-colors"
                >
                  Cerrar
                </button>
              </div>
              <div className="text-xs text-center text-slate-400 mt-2">
                Presiona ESC para cerrar
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ClientDetailsModal;