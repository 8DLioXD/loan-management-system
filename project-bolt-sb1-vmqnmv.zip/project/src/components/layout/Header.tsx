import React, { useState, useEffect } from 'react';
import { CreditCard, Calendar, Clock, Search, Bell, Sun, Moon, User, ChevronDown } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { motion } from 'framer-motion';

interface HeaderProps {
  user: {
    name: string;
    role: string;
  };
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  const { isDarkMode, toggleTheme } = useTheme();
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-slate-700/50">
      <div className="max-w-7xl mx-auto">
        <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-700/50 rounded-lg">
              <CreditCard className="h-6 w-6 text-blue-400" />
              <span className="text-lg font-medium text-white">
                Sistema de Préstamos
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-6">
              <div className="flex items-center gap-2 px-4 py-1.5 bg-slate-700/30 rounded-lg">
                <Calendar className="h-5 w-5 text-blue-400" />
                <span className="text-sm text-slate-200">
                  {currentDateTime.toLocaleDateString('es-CR', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    timeZone: 'America/Costa_Rica'
                  })}
                </span>
              </div>

              <div className="flex items-center gap-2 px-4 py-1.5 bg-slate-700/30 rounded-lg">
                <Clock className="h-5 w-5 text-blue-400" />
                <span className="text-sm font-medium text-slate-200 tabular-nums">
                  {currentDateTime.toLocaleTimeString('es-CR', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true,
                    timeZone: 'America/Costa_Rica'
                  })}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                className="p-2 text-slate-400 hover:text-slate-200 transition-colors"
                onClick={toggleTheme}
              >
                {isDarkMode ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </button>

              <button className="p-2 text-slate-400 hover:text-slate-200 transition-colors">
                <Bell className="h-5 w-5" />
              </button>

              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 text-slate-200 hover:bg-slate-700/50 rounded-lg transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
                    <User className="h-5 w-5 text-blue-400" />
                  </div>
                  <span className="text-sm font-medium">{user.name}</span>
                  <ChevronDown className="h-4 w-4 text-slate-400" />
                </button>

                {isUserMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 mt-2 w-48 bg-slate-800 rounded-lg shadow-lg py-1 border border-slate-700"
                  >
                    <button
                      onClick={onLogout}
                      className="w-full px-4 py-2 text-left text-sm text-slate-200 hover:bg-slate-700/50"
                    >
                      Cerrar Sesión
                    </button>
                  </motion.div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;