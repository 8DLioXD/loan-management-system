import React, { useState, useEffect } from 'react';
import { Calendar, Clock } from 'lucide-react';

const DateTime: React.FC = () => {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="hidden md:flex items-center bg-blue-50 dark:bg-blue-900/20 rounded-lg px-4 py-2">
      <Calendar className="w-5 h-5 text-blue-600 dark:text-blue-400 mr-2" />
      <span className="text-sm text-gray-600 dark:text-gray-300">
        {currentDateTime.toLocaleDateString('es-CR', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          timeZone: 'America/Costa_Rica'
        })}
      </span>
      <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400 ml-4 mr-2" />
      <span className="text-sm text-gray-600 dark:text-gray-300">
        {currentDateTime.toLocaleTimeString('es-CR', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
          timeZone: 'America/Costa_Rica'
        })}
      </span>
    </div>
  );
};

export default DateTime;