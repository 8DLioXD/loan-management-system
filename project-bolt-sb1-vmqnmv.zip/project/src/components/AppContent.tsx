import React from 'react';
import { useAuth } from '../context/AuthContext';
import LoginPage from './LoginPage';
import LoanDashboard from './LoanDashboard';
import { ErrorBoundary } from 'react-error-boundary';
import ErrorFallback from './ErrorFallback';

const AppContent: React.FC = () => {
  const { isAuthenticated, user, login, logout } = useAuth();

  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      {isAuthenticated && user ? (
        <LoanDashboard user={user} onLogout={logout} />
      ) : (
        <LoginPage onLogin={login} />
      )}
    </ErrorBoundary>
  );
};

export default AppContent;