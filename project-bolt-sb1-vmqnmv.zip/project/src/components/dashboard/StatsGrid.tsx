import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, AlertCircle, PiggyBank } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import { useLoan } from '../../context/LoanContext';

const StatsGrid: React.FC = () => {
  const { loans } = useLoan();

  const stats = [
    {
      title: 'Total Prestado',
      value: formatCurrency(100000),
      icon: <TrendingUp className="w-6 h-6" />,
      trend: '+100%',
      color: 'blue'
    },
    {
      title: 'Préstamos Activos',
      value: '2',
      icon: <Users className="w-6 h-6" />,
      trend: '+100%',
      color: 'green'
    },
    {
      title: 'Pagos Atrasados',
      value: '0',
      icon: <AlertCircle className="w-6 h-6" />,
      trend: '0%',
      color: 'red'
    },
    {
      title: 'Intereses Generados',
      value: formatCurrency(20000),
      icon: <PiggyBank className="w-6 h-6" />,
      trend: '+100%',
      color: 'yellow'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className={`bg-slate-800 rounded-lg p-6 border-l-4 ${
            stat.color === 'blue' ? 'border-blue-500' :
            stat.color === 'green' ? 'border-green-500' :
            stat.color === 'red' ? 'border-red-500' :
            'border-yellow-500'
          }`}
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-slate-400">{stat.title}</p>
              <h3 className={`text-2xl font-bold mt-2 ${
                stat.color === 'blue' ? 'text-blue-400' :
                stat.color === 'green' ? 'text-green-400' :
                stat.color === 'red' ? 'text-red-400' :
                'text-yellow-400'
              }`}>
                {stat.value}
              </h3>
            </div>
            <div className={`p-3 rounded-lg ${
              stat.color === 'blue' ? 'bg-blue-500/20' :
              stat.color === 'green' ? 'bg-green-500/20' :
              stat.color === 'red' ? 'bg-red-500/20' :
              'bg-yellow-500/20'
            }`}>
              {stat.icon}
            </div>
          </div>

          <div className="mt-4 flex items-center text-sm">
            <span className={stat.trend.startsWith('+') ? 'text-green-400' : 'text-slate-400'}>
              {stat.trend}
            </span>
            <span className="text-slate-400 ml-2">
              vs. mes anterior
            </span>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default StatsGrid;