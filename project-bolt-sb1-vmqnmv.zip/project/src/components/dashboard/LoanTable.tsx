import React, { useState } from 'react';
import { Edit2, DollarSign, FileText, Trash2, UserPlus } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import { formatDate } from '../../utils/dateUtils';
import { useAuth } from '../../context/AuthContext';
import { Loan } from '../../types/loan';
import { motion } from 'framer-motion';
import ClientAccessModal from '../modals/ClientAccessModal';
import ClientDetailsModal from '../modals/ClientDetailsModal';
import Toast from '../Toast';

interface LoanTableProps {
  filter: string;
  onEdit: (loan: Loan) => void;
  onPayment: (loan: Loan) => void;
  onDelete: (id: string) => void;
  loans: Loan[];
  isClient: boolean;
}

const LoanTable: React.FC<LoanTableProps> = ({ 
  filter, 
  onEdit, 
  onPayment, 
  onDelete, 
  loans,
  isClient 
}) => {
  const { createClientUser } = useAuth();
  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);
  const [isClientDetailsOpen, setIsClientDetailsOpen] = useState(false);
  const [isClientAccessOpen, setIsClientAccessOpen] = useState(false);
  const [clientAccessData, setClientAccessData] = useState<any>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const handleCreateClientUser = async (loan: Loan) => {
    try {
      const userData = await createClientUser(loan.clientName, loan.id);
      setClientAccessData(userData);
      setIsClientAccessOpen(true);
    } catch (error) {
      setToast({
        message: error instanceof Error ? error.message : 'Error al crear usuario cliente',
        type: 'error'
      });
    }
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-800 rounded-lg overflow-hidden"
      >
        <table className="min-w-full divide-y divide-slate-700">
          <thead className="bg-slate-700/50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">
                Cliente
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-slate-300 uppercase tracking-wider w-[180px]">
                Fecha Préstamo
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-slate-300 uppercase tracking-wider w-[180px]">
                Fecha Vencimiento
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-slate-300 uppercase tracking-wider">
                Monto
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-slate-300 uppercase tracking-wider">
                Interés
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-slate-300 uppercase tracking-wider">
                Total
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-slate-300 uppercase tracking-wider">
                Estado
              </th>
              <th className="px-6 py-3 text-center text-xs font-medium text-slate-300 uppercase tracking-wider">
                Acciones
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700">
            {loans.map((loan, index) => (
              <motion.tr
                key={loan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="hover:bg-slate-700/50 transition-colors"
              >
                <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                  {loan.clientName}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex flex-col items-center">
                    <span className="text-sm font-medium text-slate-300">
                      {formatDate(loan.loanDate)}
                    </span>
                    <span className="text-xs text-slate-400 mt-1">
                      {new Date(loan.loanDate).toLocaleTimeString('es-CR', {
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: true
                      })}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex flex-col items-center">
                    <span className="text-sm font-medium text-slate-300">
                      {formatDate(loan.dueDate)}
                    </span>
                    <span className="text-xs text-slate-400 mt-1">
                      {new Date(loan.dueDate).toLocaleTimeString('es-CR', {
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: true
                      })}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-white">
                  {formatCurrency(loan.amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-slate-300">
                  {loan.interestRate}%
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-white">
                  {formatCurrency(loan.amount * (1 + loan.interestRate / 100))}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    loan.paid
                      ? 'bg-green-500/20 text-green-400'
                      : new Date(loan.dueDate) < new Date()
                      ? 'bg-red-500/20 text-red-400'
                      : 'bg-blue-500/20 text-blue-400'
                  }`}>
                    {loan.paid ? 'PAGADO' : new Date(loan.dueDate) < new Date() ? 'ATRASADO' : 'ACTIVO'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center">
                  <div className="flex justify-center gap-2">
                    <button
                      onClick={() => {
                        setSelectedLoan(loan);
                        setIsClientDetailsOpen(true);
                      }}
                      className="p-1 text-slate-400 hover:text-white transition-colors"
                      title="Ver detalles"
                    >
                      <FileText className="w-4 h-4" />
                    </button>
                    {!isClient && (
                      <>
                        <button
                          onClick={() => onEdit(loan)}
                          className="p-1 text-slate-400 hover:text-white transition-colors"
                          title="Editar préstamo"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onPayment(loan)}
                          className="p-1 text-slate-400 hover:text-white transition-colors"
                          title="Registrar pago"
                        >
                          <DollarSign className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleCreateClientUser(loan)}
                          className="p-1 text-slate-400 hover:text-white transition-colors"
                          title="Crear usuario cliente"
                        >
                          <UserPlus className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDelete(loan.id)}
                          className="p-1 text-red-400 hover:text-red-300 transition-colors"
                          title="Eliminar préstamo"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </motion.div>

      <ClientDetailsModal
        isOpen={isClientDetailsOpen}
        onClose={() => setIsClientDetailsOpen(false)}
        loan={selectedLoan}
      />

      <ClientAccessModal
        isOpen={isClientAccessOpen}
        onClose={() => setIsClientAccessOpen(false)}
        userData={clientAccessData}
      />

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </>
  );
};

export default LoanTable;