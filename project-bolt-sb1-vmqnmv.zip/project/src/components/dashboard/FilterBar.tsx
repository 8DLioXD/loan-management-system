import React from 'react';
import { Plus, Download, Upload } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLoan } from '../../context/LoanContext';

interface FilterBarProps {
  currentFilter: string;
  onFilterChange: (filter: string) => void;
  onNewLoan: () => void;
  isClient: boolean;
}

const FilterBar: React.FC<FilterBarProps> = ({ currentFilter, onFilterChange, onNewLoan, isClient }) => {
  const { loans, filterLoans } = useLoan();

  const filters = [
    { id: 'todos', label: 'Todos', count: loans.length },
    { id: 'activos', label: 'Activos', count: filterLoans('activos').length },
    { id: 'pagados', label: 'Pagados', count: filterLoans('pagados').length },
    { id: 'atrasados', label: 'Atrasados', count: filterLoans('atrasados').length },
  ];

  const handleExport = () => {
    try {
      const data = {
        loans,
        exportDate: new Date().toISOString(),
        version: '1.0'
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `prestamos_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al exportar:', error);
      alert('Error al exportar los datos');
    }
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        const text = await file.text();
        const data = JSON.parse(text);
        
        if (!data.loans || !Array.isArray(data.loans)) {
          throw new Error('Formato de archivo inválido');
        }

        localStorage.setItem('loans', JSON.stringify(data.loans));
        window.location.reload();
      } catch (error) {
        console.error('Error al importar:', error);
        alert('Error al importar los datos');
      }
    };

    input.click();
  };

  return (
    <div className="flex flex-col sm:flex-row justify-between gap-4 mb-6">
      <div className="flex flex-wrap gap-2">
        {filters.map((filter, index) => (
          <motion.button
            key={filter.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => onFilterChange(filter.id)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`inline-flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200
              ${currentFilter === filter.id
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
          >
            {filter.label}
            <span className="ml-2 px-2 py-0.5 text-xs rounded-full bg-slate-700/50">
              {filter.count}
            </span>
          </motion.button>
        ))}
      </div>

      {!isClient && (
        <div className="flex gap-2">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleExport}
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            Exportar
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleImport}
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors"
          >
            <Upload className="w-4 h-4" />
            Importar
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onNewLoan}
            className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-500 transition-colors shadow-lg shadow-green-500/20"
          >
            <Plus className="w-4 h-4" />
            Nuevo Préstamo
          </motion.button>
        </div>
      )}
    </div>
  );
};

export default FilterBar;