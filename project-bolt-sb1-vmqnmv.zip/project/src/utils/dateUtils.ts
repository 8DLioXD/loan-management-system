import { DATE } from './constants';

export const toLocalDate = (date: Date | string): Date => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return new Date(d.toLocaleString('en-US', { timeZone: DATE.TIMEZONE }));
};

export const formatDate = (date: Date | string): string => {
  const d = toLocalDate(date);
  return d.toLocaleDateString('es-CR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    timeZone: DATE.TIMEZONE
  });
};

export const formatDateTime = (date: Date | string): string => {
  const d = toLocalDate(date);
  return d.toLocaleString('es-CR', {
    dateStyle: 'full',
    timeStyle: 'medium',
    timeZone: DATE.TIMEZONE
  });
};

export const toISOString = (date: Date | string): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toISOString();
};

export const isValidDate = (date: Date | string): boolean => {
  const d = new Date(date);
  return d instanceof Date && !isNaN(d.getTime());
};

export const addDays = (date: Date | string, days: number): Date => {
  const d = toLocalDate(date);
  d.setDate(d.getDate() + days);
  return d;
};

export const getDaysDifference = (start: Date | string, end: Date | string): number => {
  const startDate = toLocalDate(start);
  const endDate = toLocalDate(end);
  const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};