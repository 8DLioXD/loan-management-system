import { User } from '../types/auth';
import { Loan } from '../types/loan';
import { sanitizeInput } from './security';

const STORAGE_KEYS = {
  USERS: 'users',
  ADMINS: 'admins',
  LOANS: 'loans',
  AUTH: 'auth',
  THEME: 'theme'
} as const;

export const storage = {
  getItem: <T>(key: string, defaultValue: T): T => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error(`Error reading ${key} from storage:`, error);
      return defaultValue;
    }
  },

  setItem: (key: string, value: any): void => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Error writing ${key} to storage:`, error);
    }
  },

  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error(`Error removing ${key} from storage:`, error);
    }
  },

  getUsers: (): User[] => {
    return storage.getItem<User[]>(STORAGE_KEYS.USERS, []);
  },

  setUsers: (users: User[]): void => {
    const sanitizedUsers = users.map(user => ({
      ...user,
      username: sanitizeInput.text(user.username),
      name: sanitizeInput.text(user.name),
      email: user.email ? sanitizeInput.email(user.email) : undefined
    }));
    storage.setItem(STORAGE_KEYS.USERS, sanitizedUsers);
  },

  getLoans: (): Loan[] => {
    return storage.getItem<Loan[]>(STORAGE_KEYS.LOANS, []);
  },

  setLoans: (loans: Loan[]): void => {
    const sanitizedLoans = loans.map(loan => ({
      ...loan,
      clientName: sanitizeInput.text(loan.clientName),
      amount: sanitizeInput.number(loan.amount),
      interestRate: sanitizeInput.number(loan.interestRate)
    }));
    storage.setItem(STORAGE_KEYS.LOANS, sanitizedLoans);
  },

  clearAll: (): void => {
    Object.values(STORAGE_KEYS).forEach(key => storage.removeItem(key));
  }
};