import { z } from 'zod';
import { REGEX } from './constants';

export const userSchema = z.object({
  username: z.string()
    .min(3, 'El usuario debe tener al menos 3 caracteres')
    .max(30, 'El usuario no puede tener más de 30 caracteres')
    .regex(REGEX.USERNAME, 'Usuario inválido'),
  password: z.string()
    .min(8, 'La contraseña debe tener al menos 8 caracteres')
    .regex(REGEX.PASSWORD, 'La contraseña debe contener mayúsculas, minúsculas, números y símbolos'),
  email: z.string().email('Email inválido').optional(),
  name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
  role: z.enum(['admin', 'client']),
});

export const loanSchema = z.object({
  clientName: z.string().min(2, 'El nombre del cliente debe tener al menos 2 caracteres'),
  amount: z.number()
    .min(1, 'El monto debe ser mayor a 0')
    .max(999999999, 'El monto es demasiado alto'),
  interestRate: z.number()
    .min(0, 'La tasa de interés no puede ser negativa')
    .max(100, 'La tasa de interés no puede ser mayor a 100%'),
  loanDate: z.string().datetime(),
  dueDate: z.string().datetime(),
});

export const paymentSchema = z.object({
  amount: z.number().min(1, 'El monto debe ser mayor a 0'),
  date: z.string().datetime(),
});

export type UserValidation = z.infer<typeof userSchema>;
export type LoanValidation = z.infer<typeof loanSchema>;
export type PaymentValidation = z.infer<typeof paymentSchema>;