import { Big } from 'big.js';
import { Loan } from '../types/loan';
import { LOAN, CURRENCY } from './constants';

export const calculateInterest = (principal: number, rate: number, days: number): number => {
  try {
    const amount = new Big(principal);
    const interestRate = new Big(rate).div(100);
    const daysInYear = new Big(365);
    
    return amount
      .times(interestRate)
      .times(days)
      .div(daysInYear)
      .round(CURRENCY.DECIMALS)
      .toNumber();
  } catch (error) {
    console.error('Error calculating interest:', error);
    throw new Error('Error en el cálculo de intereses');
  }
};

export const calculateLoanStats = (loan: Loan) => {
  try {
    const currentDate = new Date();
    const loanDate = new Date(loan.loanDate);
    const dueDate = new Date(loan.dueDate);
    
    const daysElapsed = Math.floor(
      (currentDate.getTime() - loanDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    
    const daysOverdue = currentDate > dueDate
      ? Math.floor((currentDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24))
      : 0;

    const principal = new Big(loan.amount);
    const baseInterest = principal
      .times(loan.interestRate)
      .div(100)
      .round(CURRENCY.DECIMALS);

    let totalInterest = baseInterest;

    // Calcular interés adicional si está vencido
    if (daysOverdue > LOAN.GRACE_PERIOD_DAYS) {
      const additionalInterest = calculateInterest(
        principal.plus(baseInterest).toNumber(),
        loan.interestRate,
        daysOverdue - LOAN.GRACE_PERIOD_DAYS
      );
      totalInterest = totalInterest.plus(additionalInterest);
    }

    const total = principal.plus(totalInterest);
    const totalPaid = loan.payments.reduce(
      (sum, payment) => sum.plus(payment.amount),
      new Big(0)
    );

    return {
      principal: principal.toNumber(),
      baseInterest: baseInterest.toNumber(),
      totalInterest: totalInterest.toNumber(),
      total: total.toNumber(),
      totalPaid: totalPaid.toNumber(),
      remaining: Math.max(0, total.minus(totalPaid).toNumber()),
      daysElapsed,
      daysOverdue,
      isOverdue: daysOverdue > 0 && !loan.paid,
      isInGracePeriod: daysOverdue > 0 && daysOverdue <= LOAN.GRACE_PERIOD_DAYS
    };
  } catch (error) {
    console.error('Error calculating loan stats:', error);
    throw new Error('Error en el cálculo de estadísticas del préstamo');
  }
};

export const calculateMonthlyStats = (loans: Loan[]) => {
  try {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    const currentMonthStart = new Date(currentYear, currentMonth, 1);
    const lastMonthStart = new Date(currentYear, currentMonth - 1, 1);

    const filterByDateRange = (start: Date, end: Date) => 
      loans.filter(loan => {
        const loanDate = new Date(loan.loanDate);
        return loanDate >= start && loanDate < end;
      });

    const calculateTotalAmount = (filteredLoans: Loan[]) =>
      filteredLoans.reduce(
        (sum, loan) => sum.plus(loan.amount),
        new Big(0)
      ).toNumber();

    const currentMonthLoans = filterByDateRange(currentMonthStart, now);
    const lastMonthLoans = filterByDateRange(lastMonthStart, currentMonthStart);

    const currentMonthTotal = calculateTotalAmount(currentMonthLoans);
    const lastMonthTotal = calculateTotalAmount(lastMonthLoans);

    const percentageChange = lastMonthTotal === 0
      ? currentMonthTotal > 0 ? 100 : 0
      : ((currentMonthTotal - lastMonthTotal) / lastMonthTotal) * 100;

    return {
      currentMonth: {
        count: currentMonthLoans.length,
        total: currentMonthTotal
      },
      lastMonth: {
        count: lastMonthLoans.length,
        total: lastMonthTotal
      },
      percentageChange: Math.round(percentageChange * 100) / 100
    };
  } catch (error) {
    console.error('Error calculating monthly stats:', error);
    throw new Error('Error en el cálculo de estadísticas mensuales');
  }
};