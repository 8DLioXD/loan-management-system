import { THEME } from './constants';

export const initializeTheme = () => {
  const storedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  const isDark = storedTheme === 'dark' || (!storedTheme && prefersDark);
  
  document.documentElement.classList.toggle('dark', isDark);
  applyThemeVariables(isDark);
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  
  return isDark;
};

export const toggleTheme = (isDark: boolean) => {
  document.documentElement.classList.toggle('dark', isDark);
  applyThemeVariables(isDark);
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
};

const applyThemeVariables = (isDark: boolean) => {
  const root = document.documentElement;
  const theme = isDark ? THEME.dark : THEME.light;
  
  Object.entries(theme).forEach(([key, value]) => {
    root.style.setProperty(`--${key}`, value);
  });
};