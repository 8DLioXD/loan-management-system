export const SECURITY = {
  MAX_LOGIN_ATTEMPTS: 5,
  LOCKOUT_DURATION: 15 * 60 * 1000,
  PASSWORD_MIN_LENGTH: 8,
  TOKEN_EXPIRATION: 2 * 60 * 60,
  SESSION_REFRESH_INTERVAL: 30 * 60 * 1000,
  SALT_ROUNDS: 12,
  MAX_AMOUNT: 999999999,
  MIN_DATE: '2000-01-01',
  MAX_DATE: '2100-12-31',
  PASSWORD_REQUIREMENTS: {
    minLength: 8,
    minLowercase: 1,
    minUppercase: 1,
    minNumbers: 1,
    minSymbols: 1,
    USERNAME_REGEX: /^[a-zA-Z0-9_]{3,30}$/
  }
};

export const THEME = {
  light: {
    'bg-primary': '#ffffff',
    'bg-secondary': '#f3f4f6',
    'text-primary': '#111827',
    'text-secondary': '#4b5563',
    'border-color': '#e5e7eb',
    'accent-color': '#2563eb',
    'card-bg': '#ffffff',
    'input-bg': '#ffffff',
    'hover-bg': '#f9fafb'
  },
  dark: {
    'bg-primary': '#1a1a1a',
    'bg-secondary': '#2d2d2d',
    'text-primary': '#ffffff',
    'text-secondary': '#9ca3af',
    'border-color': '#404040',
    'accent-color': '#3b82f6',
    'card-bg': '#374151',
    'input-bg': '#1f2937',
    'hover-bg': '#4b5563'
  }
};

export const CURRENCY = {
  CODE: 'CRC',
  SYMBOL: '₡',
  LOCALE: 'es-CR',
  MAX_AMOUNT: 999999999,
  DECIMALS: 0
};

export const DATE = {
  TIMEZONE: 'America/Costa_Rica',
  FORMAT: {
    SHORT: 'dd/MM/yyyy',
    LONG: 'dd MMMM yyyy',
    WITH_TIME: 'dd/MM/yyyy HH:mm:ss',
  },
  MIN_DATE: '2000-01-01',
  MAX_DATE: '2100-12-31'
};

export const LOAN = {
  GRACE_PERIOD_DAYS: 15,
  DEFAULT_INTEREST_RATE: 20,
  MIN_TERM_DAYS: 7,
  MAX_TERM_DAYS: 365,
  PAYMENT_TYPES: ['TOTAL', 'PARTIAL'] as const,
  MIN_AMOUNT: 1000,
  MAX_AMOUNT: 999999999,
  MIN_INTEREST: 0,
  MAX_INTEREST: 100
};

export const REGEX = {
  USERNAME: /^[a-zA-Z0-9_]{3,30}$/,
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
  PHONE: /^\+?[1-9]\d{1,14}$/,
  EMAIL: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
};