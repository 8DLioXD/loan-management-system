import bcrypt from 'bcryptjs';
import * as jose from 'jose';
import validator from 'validator';
import DOMPurify from 'dompurify';
import { SECURITY } from './constants';

const JWT_SECRET = new TextEncoder().encode(
  import.meta.env.VITE_JWT_SECRET || 'hL6v4P#mK9$qR2@nX8*wJ3&gF5?tY7'
);

export const hashPassword = async (password: string): Promise<string> => {
  try {
    return await bcrypt.hash(password, SECURITY.SALT_ROUNDS);
  } catch (error) {
    console.error('Error hashing password:', error);
    throw new Error('Error securing password');
  }
};

export const comparePasswords = async (
  password: string,
  hashedPassword: string
): Promise<boolean> => {
  try {
    return await bcrypt.compare(password, hashedPassword);
  } catch (error) {
    console.error('Error comparing passwords:', error);
    throw new Error('Error verifying password');
  }
};

export const generateToken = async (userId: string): Promise<string> => {
  try {
    return await new jose.SignJWT({ userId })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime(`${SECURITY.TOKEN_EXPIRATION}s`)
      .sign(JWT_SECRET);
  } catch (error) {
    console.error('Error generating token:', error);
    throw new Error('Error creating session');
  }
};

export const verifyToken = async (token: string): Promise<any> => {
  try {
    const { payload } = await jose.jwtVerify(token, JWT_SECRET);
    return payload;
  } catch (error) {
    console.error('Error verifying token:', error);
    throw new Error('Invalid or expired session');
  }
};

export const sanitizeInput = {
  text: (input: string): string => {
    if (!input) return '';
    return DOMPurify.sanitize(validator.escape(input.trim()));
  },

  number: (input: number): number => {
    return Math.max(0, Math.min(input, Number.MAX_SAFE_INTEGER));
  },

  html: (input: string): string => {
    return DOMPurify.sanitize(input, {
      ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'span'],
      ALLOWED_ATTR: ['class']
    });
  },

  email: (input: string): string => {
    return validator.normalizeEmail(input.toLowerCase().trim()) || '';
  },

  sanitizeString: (input: string): string => {
    if (!input) return '';
    return validator.escape(input.trim());
  }
};

export const validateInput = {
  username: (username: string): boolean => {
    if (!username) return false;
    const sanitized = sanitizeInput.text(username);
    return validator.matches(sanitized, SECURITY.PASSWORD_REQUIREMENTS.USERNAME_REGEX);
  },

  password: (password: string): boolean => {
    if (!password) return false;
    return validator.isStrongPassword(password, {
      minLength: SECURITY.PASSWORD_REQUIREMENTS.minLength,
      minLowercase: SECURITY.PASSWORD_REQUIREMENTS.minLowercase,
      minUppercase: SECURITY.PASSWORD_REQUIREMENTS.minUppercase,
      minNumbers: SECURITY.PASSWORD_REQUIREMENTS.minNumbers,
      minSymbols: SECURITY.PASSWORD_REQUIREMENTS.minSymbols
    });
  },

  email: (email: string): boolean => {
    if (!email) return false;
    const sanitized = sanitizeInput.email(email);
    return validator.isEmail(sanitized);
  },

  amount: (amount: string | number): boolean => {
    if (!amount) return false;
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return !isNaN(num) && num > 0 && num <= SECURITY.MAX_AMOUNT;
  },

  date: (date: string): boolean => {
    if (!date) return false;
    const dateObj = new Date(date);
    return validator.isDate(date) && 
           dateObj >= new Date(SECURITY.MIN_DATE) &&
           dateObj <= new Date(SECURITY.MAX_DATE);
  },

  sanitizeString: (input: string): string => {
    if (!input) return '';
    return validator.escape(input.trim());
  }
};