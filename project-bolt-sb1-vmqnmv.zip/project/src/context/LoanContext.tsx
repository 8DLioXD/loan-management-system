import React, { createContext, useContext, useState, useEffect } from 'react';
import { Loan, Payment } from '../types/loan';
import { calculateLoanStats } from '../utils/calculations';

interface LoanContextType {
  loans: Loan[];
  addLoan: (loan: Omit<Loan, 'id' | 'paid' | 'payments'>) => void;
  updateLoan: (id: string, loan: Partial<Loan>) => void;
  deleteLoan: (id: string) => void;
  addPayment: (loanId: string, payment: Omit<Payment, 'id'>) => void;
  filterLoans: (filter: string) => Loan[];
}

const LoanContext = createContext<LoanContextType | undefined>(undefined);

export const LoanProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [loans, setLoans] = useState<Loan[]>(() => {
    try {
      const savedLoans = localStorage.getItem('loans');
      return savedLoans ? JSON.parse(savedLoans) : [];
    } catch (error) {
      console.error('Error loading loans:', error);
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('loans', JSON.stringify(loans));
    } catch (error) {
      console.error('Error saving loans:', error);
    }
  }, [loans]);

  const addLoan = (loanData: Omit<Loan, 'id' | 'paid' | 'payments'>) => {
    const newLoan: Loan = {
      ...loanData,
      id: `loan_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      paid: false,
      payments: [],
      loanDate: new Date(loanData.loanDate).toISOString(),
      dueDate: new Date(loanData.dueDate).toISOString()
    };
    setLoans(prev => [...prev, newLoan]);
  };

  const updateLoan = (id: string, loanData: Partial<Loan>) => {
    setLoans(prev => prev.map(loan => {
      if (loan.id !== id) return loan;
      
      const updatedLoan = { ...loan, ...loanData };
      if (loanData.loanDate) {
        updatedLoan.loanDate = new Date(loanData.loanDate).toISOString();
      }
      if (loanData.dueDate) {
        updatedLoan.dueDate = new Date(loanData.dueDate).toISOString();
      }
      return updatedLoan;
    }));
  };

  const deleteLoan = (id: string) => {
    setLoans(prev => prev.filter(loan => loan.id !== id));
  };

  const addPayment = (loanId: string, paymentData: Omit<Payment, 'id'>) => {
    setLoans(prev => prev.map(loan => {
      if (loan.id !== loanId) return loan;

      const newPayment: Payment = {
        ...paymentData,
        id: `payment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        date: new Date(paymentData.date).toISOString()
      };

      const updatedPayments = [...loan.payments, newPayment];
      const stats = calculateLoanStats(loan);
      const totalPaid = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
      
      return {
        ...loan,
        payments: updatedPayments,
        paid: totalPaid >= stats.total
      };
    }));
  };

  const filterLoans = (filter: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return loans.filter(loan => {
      const dueDate = new Date(loan.dueDate);
      dueDate.setHours(0, 0, 0, 0);
      
      switch (filter) {
        case 'activos':
          return !loan.paid && dueDate >= today;
        case 'pagados':
          return loan.paid;
        case 'atrasados':
          return !loan.paid && dueDate < today;
        default:
          return true;
      }
    });
  };

  return (
    <LoanContext.Provider value={{
      loans,
      addLoan,
      updateLoan,
      deleteLoan,
      addPayment,
      filterLoans
    }}>
      {children}
    </LoanContext.Provider>
  );
};

export const useLoan = () => {
  const context = useContext(LoanContext);
  if (context === undefined) {
    throw new Error('useLoan must be used within a LoanProvider');
  }
  return context;
};