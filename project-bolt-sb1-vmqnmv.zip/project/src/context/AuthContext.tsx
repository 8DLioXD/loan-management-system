import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AuthState } from '../types/auth';
import { hashPassword, comparePasswords, generateToken, verifyToken, validateInput, sanitizeInput } from '../utils/security';

interface AuthContextType extends AuthState {
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  createAdmin: (adminData: Omit<User, 'id' | 'role'>) => Promise<User>;
  createClientUser: (clientName: string, loanId: string) => Promise<User>;
  resetPassword: {
    checkUser: (username: string) => Promise<boolean>;
    change: (username: string, currentPassword: string, newPassword: string) => Promise<void>;
  };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [auth, setAuth] = useState<AuthState>(() => {
    try {
      const token = localStorage.getItem('authToken');
      if (!token) return { user: null, isAuthenticated: false };

      const savedAuth = localStorage.getItem('auth');
      return savedAuth ? JSON.parse(savedAuth) : { user: null, isAuthenticated: false };
    } catch (error) {
      console.error('Error loading auth state:', error);
      return { user: null, isAuthenticated: false };
    }
  });

  const [loginAttempts, setLoginAttempts] = useState<{[key: string]: number}>({});
  const [loginBlockedUntil, setLoginBlockedUntil] = useState<{[key: string]: number}>({});

  useEffect(() => {
    try {
      localStorage.setItem('auth', JSON.stringify(auth));
    } catch (error) {
      console.error('Error saving auth state:', error);
    }
  }, [auth]);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      if (!username || !password) {
        throw new Error('Username and password are required');
      }

      if (!validateInput.username(username)) {
        throw new Error('Invalid username format');
      }

      const now = Date.now();
      const blockedUntil = loginBlockedUntil[username] || 0;
      if (now < blockedUntil) {
        const minutesLeft = Math.ceil((blockedUntil - now) / (60 * 1000));
        throw new Error(`Account is temporarily locked. Please try again in ${minutesLeft} minutes.`);
      }

      const attempts = (loginAttempts[username] || 0) + 1;
      setLoginAttempts(prev => ({ ...prev, [username]: attempts }));

      if (attempts >= 5) {
        const blockUntil = now + 15 * 60 * 1000; // 15 minutes
        setLoginBlockedUntil(prev => ({ ...prev, [username]: blockUntil }));
        throw new Error('Too many failed attempts. Account locked for 15 minutes.');
      }

      if (username === 'LioXD' && password === 'admin123') {
        const token = await generateToken('admin');
        localStorage.setItem('authToken', token);
        
        setAuth({
          user: {
            id: 'admin',
            username: 'LioXD',
            role: 'admin',
            name: 'Administrador',
            password: ''
          },
          isAuthenticated: true
        });

        setLoginAttempts(prev => ({ ...prev, [username]: 0 }));
        return true;
      }

      const admins = JSON.parse(localStorage.getItem('admins') || '[]');
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      
      const user = [...admins, ...users].find(u => u.username === username);
      
      if (!user) {
        throw new Error('Invalid credentials');
      }

      const isValid = await comparePasswords(password, user.password);
      if (!isValid) {
        throw new Error('Invalid credentials');
      }

      const token = await generateToken(user.id);
      localStorage.setItem('authToken', token);

      setAuth({
        user: { ...user, password: '' },
        isAuthenticated: true
      });

      setLoginAttempts(prev => ({ ...prev, [username]: 0 }));
      return true;

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
      console.error('Login error:', errorMessage);
      throw new Error(errorMessage);
    }
  };

  const logout = () => {
    try {
      localStorage.removeItem('authToken');
      localStorage.removeItem('currentUser');
      setAuth({ user: null, isAuthenticated: false });
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  const createAdmin = async (adminData: Omit<User, 'id' | 'role'>): Promise<User> => {
    try {
      if (!validateInput.username(adminData.username)) {
        throw new Error('Invalid username format');
      }

      if (!validateInput.password(adminData.password)) {
        throw new Error('Password does not meet security requirements');
      }

      if (!validateInput.email(adminData.email)) {
        throw new Error('Invalid email format');
      }

      const admins = JSON.parse(localStorage.getItem('admins') || '[]');
      
      if (admins.some((admin: User) => admin.username === adminData.username)) {
        throw new Error('Username already exists');
      }

      const hashedPassword = await hashPassword(adminData.password);
      
      const newAdmin: User = {
        ...adminData,
        id: `admin_${Date.now()}`,
        role: 'admin',
        password: hashedPassword
      };

      admins.push(newAdmin);
      localStorage.setItem('admins', JSON.stringify(admins));

      const { password, ...adminWithoutPassword } = newAdmin;
      return adminWithoutPassword as User;
    } catch (error) {
      console.error('Error creating admin:', error);
      throw error;
    }
  };

  const createClientUser = async (clientName: string, loanId: string): Promise<User> => {
    try {
      if (!clientName || !loanId) {
        throw new Error('Client name and loan ID are required');
      }

      const sanitizedName = sanitizeInput.text(clientName);
      const timestamp = Date.now();
      const username = `client_${timestamp}`;
      const password = Math.random().toString(36).slice(-8) + Math.random().toString(36).slice(-8);
      
      // Hash the password before storing
      const hashedPassword = await hashPassword(password);
      
      const newUser: User = {
        id: `user_${timestamp}`,
        username,
        password: hashedPassword,
        role: 'client',
        clientId: loanId,
        name: sanitizedName
      };

      // Get existing users and check for duplicates
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      if (users.some((user: User) => user.username === username)) {
        throw new Error('Username already exists');
      }

      // Save the new user
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));

      // Return user data with unhashed password for first-time access
      return { ...newUser, password: password };
    } catch (error) {
      console.error('Error creating client user:', error);
      throw new Error('Failed to create client user');
    }
  };

  const resetPassword = {
    checkUser: async (username: string): Promise<boolean> => {
      try {
        if (username === 'LioXD') return true;
        
        const admins = JSON.parse(localStorage.getItem('admins') || '[]');
        if (admins.some((a: User) => a.username === username)) return true;

        const users = JSON.parse(localStorage.getItem('users') || '[]');
        return users.some((u: User) => u.username === username);
      } catch (error) {
        console.error('Error checking user:', error);
        return false;
      }
    },

    change: async (username: string, currentPassword: string, newPassword: string): Promise<void> => {
      try {
        if (!validateInput.password(newPassword)) {
          throw new Error('New password does not meet security requirements');
        }

        if (username === 'LioXD') {
          if (currentPassword !== 'admin123') {
            throw new Error('Current password is incorrect');
          }
          return;
        }

        const admins = JSON.parse(localStorage.getItem('admins') || '[]');
        const adminIndex = admins.findIndex((a: User) => a.username === username);
        
        if (adminIndex !== -1) {
          const isValid = await comparePasswords(currentPassword, admins[adminIndex].password);
          if (!isValid) {
            throw new Error('Current password is incorrect');
          }
          
          const hashedPassword = await hashPassword(newPassword);
          admins[adminIndex].password = hashedPassword;
          localStorage.setItem('admins', JSON.stringify(admins));
          return;
        }

        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const userIndex = users.findIndex((u: User) => u.username === username);
        
        if (userIndex === -1) {
          throw new Error('User not found');
        }

        const isValid = await comparePasswords(currentPassword, users[userIndex].password);
        if (!isValid) {
          throw new Error('Current password is incorrect');
        }

        const hashedPassword = await hashPassword(newPassword);
        users[userIndex].password = hashedPassword;
        localStorage.setItem('users', JSON.stringify(users));
      } catch (error) {
        console.error('Error changing password:', error);
        throw error;
      }
    }
  };

  return (
    <AuthContext.Provider value={{
      ...auth,
      login,
      logout,
      createAdmin,
      createClientUser,
      resetPassword
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};