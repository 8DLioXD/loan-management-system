export type UserRole = 'admin' | 'client';

export interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  clientId?: string; // Para usuarios cliente, referencia a sus préstamos
  name: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}