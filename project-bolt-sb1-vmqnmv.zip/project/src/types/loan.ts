export interface Loan {
  id: string;
  clientName: string;
  amount: number;
  interestRate: number;
  loanDate: string;
  dueDate: string;
  paid: boolean;
  payments: Payment[];
}

export interface Payment {
  id: string;
  amount: number;
  date: string;
}

export interface LoanFormData {
  clientName: string;
  amount: string;
  interestRate: string;
  loanDate: string;
  dueDate: string;
}

export interface PaymentFormData {
  amount: string;
  date: string;
}

export interface LoanStats {
  totalLent: number;
  activeLoans: number;
  latePayments: number;
  totalInterest: number;
  monthlyTrend: {
    totalLent: number;
    count: number;
  };
}