import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { LoanProvider } from './context/LoanContext';
import { ThemeProvider } from './context/ThemeContext';
import AppContent from './components/AppContent';
import { ErrorBoundary } from 'react-error-boundary';
import ErrorFallback from './components/ErrorFallback';

export default function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <ThemeProvider>
        <AuthProvider>
          <LoanProvider>
            <AppContent />
          </LoanProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}